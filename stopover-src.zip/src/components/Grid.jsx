/* eslint-disable no-unused-vars */
// Mandatory CSS required by the Data Grid
import 'ag-grid-community/styles/ag-grid.css';
// Optional Theme applied to the Data Grid
import 'ag-grid-community/styles/ag-theme-quartz.css';
// React Data Grid Component
import { AgGridReact } from 'ag-grid-react';


const pagination = true;
const paginationPageSize = 500;
const paginationPageSizeSelector = [200, 500, 1000];

const Grid = ({ data, columnNames, columnMapping, tableName, setActiveItem}) =>  {
    const colDefs = Object.keys(data[0]).filter(key => key && key !== "__EMPTY").reduce((a,b) => {
        a.push({ field:b, filter: true, floatingFilter: true  });

        return a;
    }, []);

    const handleRowClick = (event) => {
        // console.log(event);
        setActiveItem({ info:event.data, table:tableName});
    }

    return (
        // wrapping container with theme & size
        <div
            className="ag-theme-quartz" // applying the Data Grid theme
            style={{ height: "100%" }} // the Data Grid will fill the size of the parent container
        >
            <AgGridReact 
                rowData={data} 
                columnDefs={colDefs} 
                pagination={pagination}
                paginationPageSize={paginationPageSize}
                paginationPageSizeSelector={paginationPageSizeSelector}
                onRowClicked={handleRowClick}
            />

        </div>
    );
}


export default Grid;