export const columnNames = {
    persons:[{label:'Name', columns:['LAST NAME', 'FIRST NAME'] }, {label:'Gender', columns:['GENDER']}, {label:'Occupation', columns:['OCCUPATION']} ],
    institutions:[{label:'Name', columns:['INSTITUTION NAME']}, {label:'Place', columns:['Place']}, {label:'Foundation Date', columns:['Foundation date']}, {label:'Director', columns:['Director']}],
    scientific_collection:[{label:'Common Name', columns:['COMMON NAME']}, { label:'Inventory Number', columns:['Inventory Number']}, {label:'Collection Date', columns:['Collection date']}],
    documents:[{label:'Title', columns:['TITLE / NAME']}, { label:'Place', columns:['PLACE']}, { label:'Year/Date', columns:['YEAR  / DATE']}]
}