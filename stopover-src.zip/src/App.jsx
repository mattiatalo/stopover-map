import Main from "./main/Main";

function App() {

  return (
    <>
      <Main />
    </>
  )
}

export default App
